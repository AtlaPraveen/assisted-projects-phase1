package assistedpractice2;

interface First 
{  
    default void show() 
    { 
        System.out.println("Default First"); 
    } 
} 
interface Second 
{  
    default void show() 
    { 
        System.out.println("Default Second"); 
    } 
}  

public class Diamondprob implements First,Second {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Diamondprob ob = new Diamondprob(); 
        ob.show(); 

	}

	@Override
	public void show() {
		// TODO Auto-generated method stub
		First.super.show();
		Second.super.show(); 
	}

}