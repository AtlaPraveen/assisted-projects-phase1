package assistedpractice1;
import java.util.*;

public class Mapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		  HashMap<Integer,String> ft = new HashMap<Integer,String>();
		  ft.put(1, "vasu");
		  ft.put(2, "vijay");
		  ft.put(3, "munna");
		  System.out.println("Hash Map");
		   for(Map.Entry m:ft.entrySet()){
			   System.out.println(m.getKey()+" "+m.getValue());       
		   }
		   Hashtable<Integer,String>st=new Hashtable<Integer,String>();
		   st.put(11, "siva");
		   st.put(12, "ramu");
		   st.put(13, "vishnu");
		   System.out.println("Hash Table");
		   for(Map.Entry n:ft.entrySet()){
			   System.out.println(n.getKey()+" "+n.getValue());       
		   }
		   TreeMap<Integer,String>tt=new TreeMap<Integer,String>();
		   tt.put(21, "rajesh");
		   tt.put(22, "suresh");
		   tt.put(23, "kirthi");
		   System.out.println("Tree Map");
		   for(Map.Entry p:ft.entrySet()){
			   System.out.println(p.getKey()+" "+p.getValue());       
		   }
		  

	}

}
