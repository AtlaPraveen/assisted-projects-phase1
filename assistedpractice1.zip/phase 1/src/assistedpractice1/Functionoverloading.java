package assistedpractice1;

public class Functionoverloading {
	int addtwonumbers(int a,int b)
	{
		return a+b;
	}
    int area(float p)
    {
    	double area=3.14*p*p;
    	int carea=(int)area;
    	return carea;
    }
    int area(int l,int b)
    {
    	int recarea=l*b;
    	return recarea;
    }
    int area(int s)
    {
    	int sqarea=s*s;
    	return sqarea;
    }
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Functionoverloading fo=new Functionoverloading();
		System.out.println("addition of two numbers :"+fo.addtwonumbers(6,8));
		System.out.println("area of circle :"+fo.area(6.786F));
		System.out.println("area of rectangle :"+fo.area(5,8));
		System.out.println("area of square :"+fo.area(56));
		

	}

}

